import React, { useState } from 'react';
import { Header } from './components/Header';
import { translateToLibras, generateIllustration, generateSymptomIllustration } from './services/geminiService';
import { LoadingState, TranslationResult } from './types';
import { FileText, Wand2, Download, AlertCircle, Loader2, CheckSquare, RefreshCw, AlertTriangle, Settings, MessageCircle, Activity } from 'lucide-react';
import { jsPDF } from "jspdf";

// --- DADOS DOS SINTOMAS ---
interface Symptom {
  id: string;
  label: string;
  librasDescription: string;
  placeholderUrl: string;
  warning?: string; 
}

const SYMPTOMS_DATA: Symptom[] = [
  // --- SINTOMAS GERAIS ---
  { 
    id: 'dor_cabeca', 
    label: 'Dor de cabeça', 
    librasDescription: 'Mão em "L" tocando a têmpora repetidamente, expressão de dor.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Dor+de+Cabeca'
  },
  { 
    id: 'febre', 
    label: 'Febre', 
    librasDescription: 'Dorso da mão tocando a testa, expressão de calor.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Febre'
  },
  { 
    id: 'tosse', 
    label: 'Tosse', 
    librasDescription: 'Mão em "C" batendo levemente no peito/esôfago.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Tosse'
  },
  { 
    id: 'falta_ar', 
    label: 'Falta de ar', 
    librasDescription: 'Mãos abertas no peito movendo para cima/baixo, ofegante.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Falta+de+Ar'
  },
  { 
    id: 'nausea', 
    label: 'Náusea/Enjoo', 
    librasDescription: 'Mão em garra girando no estômago, expressão de asco.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Nausea'
  },
  { 
    id: 'vomito', 
    label: 'Vômito', 
    librasDescription: 'Mãos saindo da boca para frente abrindo os dedos.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Vomito'
  },
  { 
    id: 'dor_abdominal', 
    label: 'Dor abdominal', 
    librasDescription: 'Mão tocando a barriga com expressão de dor.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Dor+Abdominal'
  },
  { 
    id: 'tontura', 
    label: 'Tontura', 
    librasDescription: 'Mão em garra girando na testa ou ao redor da cabeça.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Tontura'
  },
  { 
    id: 'dor_peito', 
    label: 'Dor no peito', 
    librasDescription: 'Mão tocando o centro do peito com força, expressão de dor.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Dor+no+Peito'
  },
  { 
    id: 'coriza', 
    label: 'Coriza', 
    librasDescription: 'Dedos pinça descendo pelo nariz, simulando escorrer.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Coriza'
  },
  // --- NOVOS SINTOMAS ---
  {
    id: 'alergia',
    label: 'Alergias',
    librasDescription: 'Mão coçando dorso da outra mão ou braço repetidamente.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Alergia'
  },
  {
    id: 'lesoes_pele',
    label: 'Lesões na pele',
    librasDescription: 'Apontar local e fazer círculo indicando a mancha/ferida.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Lesoes+Pele'
  },
  {
    id: 'dor_ocular',
    label: 'Dor ocular',
    librasDescription: 'Mão em "C" próxima ao olho com expressão de dor.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Dor+no+Olho'
  },
  {
    id: 'dor_face',
    label: 'Dor na face',
    librasDescription: 'Mão aberta passando no rosto com expressão de dor.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Dor+na+Face'
  },
  {
    id: 'dor_corpo',
    label: 'Dor no corpo',
    librasDescription: 'Mãos passando pelo corpo, expressão de dor/cansaço.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Dor+no+Corpo'
  },
  // --- PROCEDIMENTOS ---
  {
    id: 'solicitacao_exames',
    label: 'Solicitação de Exames',
    librasDescription: 'Sinal de PAPEL + escrever + sinal de EXAMINAR.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Pedir+Exames',
    warning: 'Somente por consulta agendada'
  },
  {
    id: 'receitas',
    label: 'Receitas Médicas',
    librasDescription: 'Sinal de PAPEL + sinal de CARIMBAR/ASSINAR.',
    placeholderUrl: 'https://placehold.co/400x300/e2e8f0/1e293b?text=Sinal:+Receita',
    warning: 'Somente por consulta agendada'
  }
];

const App: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [status, setStatus] = useState<LoadingState>(LoadingState.IDLE);
  const [result, setResult] = useState<TranslationResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [missingKeyError, setMissingKeyError] = useState<boolean>(false);
  
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [symptomImages, setSymptomImages] = useState<Record<string, string>>({});
  const [loadingSymptoms, setLoadingSymptoms] = useState<Record<string, boolean>>({});

  const generateSymptomImageIfNeeded = async (symptomId: string) => {
    if (symptomImages[symptomId] || loadingSymptoms[symptomId]) return;

    const symptom = SYMPTOMS_DATA.find(s => s.id === symptomId);
    if (!symptom) return;

    setLoadingSymptoms(prev => ({ ...prev, [symptomId]: true }));
    try {
      const base64Image = await generateSymptomIllustration(symptom.label, symptom.librasDescription);
      if (base64Image) {
        setSymptomImages(prev => ({ ...prev, [symptomId]: base64Image }));
      }
    } catch (err: any) {
      console.error("Erro ao gerar imagem do sintoma:", err);
      if (err.message === "API_KEY_MISSING") {
        setMissingKeyError(true);
      }
    } finally {
      setLoadingSymptoms(prev => ({ ...prev, [symptomId]: false }));
    }
  };

  const toggleSymptom = (id: string) => {
    setSelectedSymptoms(prev => {
      const isSelected = prev.includes(id);
      if (!isSelected) {
        generateSymptomImageIfNeeded(id);
        return [...prev, id];
      } else {
        return prev.filter(item => item !== id);
      }
    });
  };

  const handleTranslate = async () => {
    if (!inputText.trim()) return;
    
    setStatus(LoadingState.TRANSLATING_TEXT);
    setErrorMsg(null);
    setResult(null);
    setMissingKeyError(false);

    try {
      const textResult = await translateToLibras(inputText);
      
      setStatus(LoadingState.GENERATING_IMAGE);
      const imageUrl = await generateIllustration(textResult.explanation);

      setResult({
        originalText: inputText,
        librasGloss: textResult.gloss,
        explanation: textResult.explanation,
        imageUrl: imageUrl || undefined
      });
      setStatus(LoadingState.SUCCESS);

    } catch (error: any) {
      console.error(error);
      if (error.message === "API_KEY_MISSING") {
        setMissingKeyError(true);
        setStatus(LoadingState.IDLE);
      } else {
        setErrorMsg(error.message || "Ocorreu um erro desconhecido.");
        setStatus(LoadingState.ERROR);
      }
    }
  };

  const handleDownloadPDF = () => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 15;
    const contentWidth = pageWidth - (margin * 2);
    
    let yPos = 15;

    // --- Header ---
    doc.setFontSize(14);
    doc.setTextColor(16, 185, 129); // Emerald
    doc.setFont("helvetica", "bold");
    doc.text("LibrasMed - Orientação Médica", margin, yPos);

    doc.setFontSize(8);
    doc.setTextColor(100);
    doc.setFont("helvetica", "normal");
    const dateStr = new Date().toLocaleDateString('pt-BR');
    doc.text(`Data: ${dateStr}`, pageWidth - margin, yPos, { align: 'right' });
    
    yPos += 5;
    doc.setDrawColor(200);
    doc.setLineWidth(0.5);
    doc.line(margin, yPos, pageWidth - margin, yPos);
    yPos += 8;

    // --- 1. Original & Translation ---
    if (result) {
      // Original
      doc.setFontSize(10);
      doc.setTextColor(0);
      doc.setFont("helvetica", "bold");
      doc.text("Prescrição Original:", margin, yPos);
      yPos += 5;
      doc.setFont("helvetica", "normal");
      const originalLines = doc.splitTextToSize(result.originalText, contentWidth);
      doc.text(originalLines, margin, yPos);
      yPos += (originalLines.length * 4) + 4;

      // Gloss
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(0, 80, 0);
      doc.text("Libras (Glossa):", margin, yPos);
      yPos += 5;
      doc.setFont("courier", "bold");
      doc.setFontSize(10);
      const glossLines = doc.splitTextToSize(result.librasGloss, contentWidth - 4);
      const glossHeight = (glossLines.length * 4) + 4;
      doc.setFillColor(240, 253, 244);
      doc.rect(margin, yPos - 1, contentWidth, glossHeight, 'F');
      doc.text(glossLines, margin + 2, yPos + 3);
      yPos += glossHeight + 5;

      // Explanation
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(0);
      doc.text("Instruções:", margin, yPos);
      yPos += 5;
      doc.setFont("helvetica", "normal");
      const explLines = doc.splitTextToSize(result.explanation, contentWidth);
      doc.text(explLines, margin, yPos);
      yPos += (explLines.length * 4) + 5;

      // Main Image (Small to save space)
      if (result.imageUrl) {
        try {
          const imgSize = 40; 
          if (yPos + imgSize < pageHeight - 20) {
             doc.addImage(result.imageUrl, 'PNG', margin, yPos, imgSize, imgSize);
             yPos += imgSize + 5;
          }
        } catch (e) {}
      }
    }

    // --- 2. Symptoms Compact List ---
    if (selectedSymptoms.length > 0) {
      // Force new page if space is tight (< 50mm left)
      if (yPos > pageHeight - 50) {
        doc.addPage();
        yPos = 15;
      }

      doc.setFontSize(11);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(0);
      doc.text("Sintomas e Solicitações:", margin, yPos);
      yPos += 8;

      const activeSymptoms = SYMPTOMS_DATA.filter(s => selectedSymptoms.includes(s.id));
      
      activeSymptoms.forEach((sym) => {
         const imgH = 25; 
         const imgW = 25;
         
         if (yPos + imgH > pageHeight - 15) {
           doc.addPage();
           yPos = 15;
         }

         const symImage = symptomImages[sym.id];
         if (symImage) {
           try {
             doc.addImage(symImage, 'PNG', margin, yPos, imgW, imgH);
           } catch (e) {}
         } else {
             doc.setDrawColor(220);
             doc.rect(margin, yPos, imgW, imgH);
             doc.setFontSize(7);
             doc.text("Sem Img", margin + 2, yPos + 12);
         }

         const txtX = margin + imgW + 4;
         const txtW = contentWidth - imgW - 4;

         doc.setFontSize(10);
         doc.setTextColor(0);
         doc.setFont("helvetica", "bold");
         doc.text(sym.label, txtX, yPos + 4);
         
         doc.setFont("helvetica", "normal");
         doc.setFontSize(9);
         doc.setTextColor(60);
         const descLines = doc.splitTextToSize(sym.librasDescription, txtW);
         doc.text(descLines, txtX, yPos + 9);
         
         if (sym.warning) {
             const wy = yPos + 9 + (descLines.length * 3.5);
             doc.setFont("helvetica", "bold");
             doc.setTextColor(220, 0, 0);
             doc.setFontSize(8);
             doc.text(`* ${sym.warning}`, txtX, wy);
         }
         
         yPos += imgH + 4; 
      });
    }

    // --- Footer ---
    doc.setFontSize(7);
    doc.setTextColor(150);
    doc.setFont("helvetica", "italic");
    doc.text(
      "Documento auxiliar gerado por IA. Consulte um profissional de saúde.",
      pageWidth / 2,
      pageHeight - 10,
      { align: 'center' }
    );

    doc.save("LibrasMed_Prescricao.pdf");
  };

  const isProcessing = status === LoadingState.TRANSLATING_TEXT || status === LoadingState.GENERATING_IMAGE;

  return (
    <div className="min-h-screen bg-slate-50 text-gray-800 flex flex-col">
      <Header />
      
      {/* Alert for missing API Key */}
      {missingKeyError && (
        <div className="max-w-7xl mx-auto px-4 mt-6 w-full animate-pulse">
          <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-lg shadow-sm flex items-start gap-3">
             <Settings className="w-5 h-5 text-red-600 mt-1" />
             <div>
               <h3 className="text-red-800 font-bold">Configuração Necessária no GitHub</h3>
               <p className="text-red-700 text-sm mt-1">
                 Para o sistema funcionar online, você precisa adicionar a chave como um SECRET no repositório.
               </p>
               <div className="mt-2 bg-white p-2 rounded border border-red-200 text-xs font-mono text-red-600 break-all select-all">
                  Chave a configurar: AIzaSyAeNvEgLv9dy-8IEwPqXGbYYrT16vJFDHM
               </div>
               <p className="text-red-700 text-xs mt-2">
                 Vá em <strong>Settings</strong> {'>'} <strong>Secrets and variables</strong> {'>'} <strong>Actions</strong>. Clique em <strong>New repository secret</strong>.<br/>
                 Nome: <strong>API_KEY</strong> | Valor: (Copie a chave acima).<br/>
                 Depois, vá em Actions e reinicie o deploy.
               </p>
             </div>
          </div>
        </div>
      )}
      
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* LEFT COLUMN: Inputs */}
          <div className="space-y-6">
            
            {/* 1. Text Input Card */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-600" />
                Orientação Médica
              </h2>
              <textarea
                className="w-full h-32 p-4 bg-slate-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all resize-none text-base"
                placeholder="Digite a prescrição ou orientação..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                disabled={isProcessing}
              />
              
              <div className="mt-4 flex justify-end">
                <button
                  onClick={handleTranslate}
                  disabled={!inputText.trim() || isProcessing}
                  className="w-full sm:w-auto px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-300 text-white font-semibold rounded-lg shadow-md transition-all flex items-center justify-center gap-2"
                >
                  {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                  Traduzir
                </button>
              </div>
            </div>

            {/* 2. Symptoms Checklist Card */}
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 flex flex-col h-[500px]">
              <h2 className="text-lg font-semibold mb-2 flex items-center gap-2 text-gray-800">
                <Activity className="w-5 h-5 text-emerald-600" />
                Sintomas e Solicitações
              </h2>
              <p className="text-xs text-gray-500 mb-4">Selecione para incluir no PDF e gerar visualização.</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 overflow-y-auto custom-scrollbar pr-2 flex-grow">
                {SYMPTOMS_DATA.map((symptom) => (
                  <label 
                    key={symptom.id} 
                    className={`
                      flex flex-col p-2.5 rounded-lg border cursor-pointer transition-all relative select-none
                      ${selectedSymptoms.includes(symptom.id) 
                        ? 'bg-emerald-50 border-emerald-500 shadow-sm' 
                        : 'bg-white border-gray-100 hover:border-emerald-200 hover:bg-slate-50'
                      }
                    `}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                        checked={selectedSymptoms.includes(symptom.id)}
                        onChange={() => toggleSymptom(symptom.id)}
                      />
                      <span className={`text-sm font-medium ${selectedSymptoms.includes(symptom.id) ? 'text-emerald-900' : 'text-gray-700'}`}>
                        {symptom.label}
                      </span>
                    </div>
                    {symptom.warning && (
                      <span className="ml-6 text-[10px] font-bold text-amber-600 flex items-center gap-1 mt-0.5">
                        <AlertTriangle size={8} /> Agendamento
                      </span>
                    )}
                  </label>
                ))}
              </div>
            </div>

            {/* Status Messages */}
            {status === LoadingState.TRANSLATING_TEXT && (
              <div className="bg-emerald-50 text-emerald-800 p-4 rounded-xl flex items-center gap-3 animate-pulse border border-emerald-100">
                <Loader2 className="w-5 h-5 animate-spin" />
                Processando tradução de texto...
              </div>
            )}
            {status === LoadingState.GENERATING_IMAGE && (
              <div className="bg-indigo-50 text-indigo-800 p-4 rounded-xl flex items-center gap-3 animate-pulse border border-indigo-100">
                <Loader2 className="w-5 h-5 animate-spin" />
                Criando ilustração médica IA...
              </div>
            )}
            {status === LoadingState.ERROR && (
              <div className="bg-red-50 text-red-700 p-4 rounded-xl flex items-center gap-3 border border-red-100">
                <AlertCircle className="w-5 h-5" />
                {errorMsg}
              </div>
            )}
          </div>

          {/* RIGHT COLUMN: Outputs */}
          <div className="space-y-6">
            
            {/* Translation Output */}
            {result && (
              <div className="bg-white overflow-hidden rounded-2xl shadow-sm border border-emerald-100 animate-in fade-in zoom-in-95 duration-300">
                <div className="bg-gradient-to-r from-emerald-50 to-white px-6 py-3 border-b border-emerald-100 flex items-center justify-between">
                  <h3 className="font-semibold text-emerald-900">Resultado da Tradução</h3>
                  <span className="text-[10px] uppercase font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">Libras</span>
                </div>
                <div className="p-6">
                  <div className="mb-4">
                    <p className="text-xs text-gray-500 uppercase tracking-wide font-bold mb-1">Glossa (Gramática):</p>
                    <p className="text-lg font-mono font-bold text-emerald-800 leading-relaxed bg-emerald-50/50 p-3 rounded-lg border border-emerald-100/50">
                      {result.librasGloss}
                    </p>
                  </div>
                  
                  <div className="mb-4">
                     <p className="text-xs text-gray-500 uppercase tracking-wide font-bold mb-1">Explicação:</p>
                     <p className="text-gray-700 text-sm leading-relaxed">
                      {result.explanation}
                    </p>
                  </div>
                  
                  {result.imageUrl && (
                      <div className="mt-4 border border-gray-100 rounded-lg overflow-hidden bg-white">
                        <img 
                          src={result.imageUrl} 
                          alt="Ilustração médica" 
                          className="w-full h-48 object-contain"
                        />
                      </div>
                  )}
                  
                  <button
                    onClick={handleDownloadPDF}
                    className="w-full mt-6 py-3 bg-white hover:bg-emerald-50 text-gray-700 font-semibold rounded-xl border-2 border-gray-200 hover:border-emerald-500 hover:text-emerald-700 transition-all flex items-center justify-center gap-2"
                  >
                    <Download className="w-5 h-5" />
                    Baixar PDF
                  </button>
                </div>
              </div>
            )}

            {/* Selected Symptoms Visual Cards */}
            {selectedSymptoms.length > 0 && (
               <div className="space-y-3">
                  <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
                    <CheckSquare className="w-4 h-4 text-emerald-600" />
                    <h3 className="font-semibold text-gray-800 text-sm">Visualização dos Itens Selecionados</h3>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    {SYMPTOMS_DATA.filter(s => selectedSymptoms.includes(s.id)).map(symptom => {
                      const isLoading = loadingSymptoms[symptom.id];
                      const hasImage = !!symptomImages[symptom.id];
                      
                      return (
                        <div key={symptom.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex flex-col h-full">
                           <div className="aspect-[4/3] bg-gray-50 relative group border-b border-gray-50">
                              {isLoading ? (
                                <div className="absolute inset-0 flex flex-col items-center justify-center text-emerald-600">
                                  <Loader2 className="w-5 h-5 animate-spin" />
                                </div>
                              ) : (
                                <>
                                  <img 
                                    src={hasImage ? symptomImages[symptom.id] : symptom.placeholderUrl} 
                                    alt={symptom.label}
                                    className="w-full h-full object-cover p-2"
                                  />
                                  {!hasImage && !missingKeyError && (
                                    <div className="absolute inset-0 bg-white/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                      <button 
                                        onClick={() => generateSymptomImageIfNeeded(symptom.id)}
                                        className="bg-emerald-600 text-white p-1.5 rounded-full shadow-lg"
                                        title="Gerar Imagem IA"
                                      >
                                        <RefreshCw size={14} />
                                      </button>
                                    </div>
                                  )}
                                </>
                              )}
                           </div>
                           <div className="p-3 flex flex-col flex-grow justify-between">
                              <div>
                                <h4 className="font-bold text-gray-800 text-sm leading-tight mb-1">{symptom.label}</h4>
                                <p className="text-[10px] text-gray-500 leading-tight">
                                   {symptom.librasDescription}
                                </p>
                              </div>
                              {symptom.warning && (
                                <div className="mt-2 text-[9px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded w-fit">
                                  {symptom.warning}
                                </div>
                              )}
                           </div>
                        </div>
                      );
                    })}
                  </div>
               </div>
            )}
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-gray-200 mt-auto">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-500">
           <div>© 2024 LibrasMed AI</div>
           <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4 mt-2 sm:mt-0">
              <span>Dev: <strong>Jaime Eduardo</strong></span>
              <a href="https://wa.me/5551985502897" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-emerald-600">
                <MessageCircle size={12} /> (51) 98550-2897
              </a>
           </div>
        </div>
      </footer>
    </div>
  );
};

export default App;